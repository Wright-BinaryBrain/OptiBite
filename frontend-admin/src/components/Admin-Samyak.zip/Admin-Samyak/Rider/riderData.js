const data = [
    {
        id: "1",
        image: "./RiderPP/pp.jpg",
        username: "msamyak",
        title: "Delivery boy",
        contact: "2211334",
        address: "Apt 187",
        email: "samyak@mail.com"
    },
    {
        id: "2",
        image: "pp.jpg",
        username: "aryan",
        title: "Sales man",
        contact: "2211222",
        address: "Suite 300",
        email: "aaryan@mail.com"
    }
]

export default data;