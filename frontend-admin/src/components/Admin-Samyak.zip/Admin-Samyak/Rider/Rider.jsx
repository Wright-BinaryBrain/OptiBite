import React, { useEffect, useState } from "react";
import Top from "../Rider/Top";
import Table from "./Table";
import RiderAdd from "./RiderAdd";
import RiderEdit from "./RiderEdit";
import axios from "axios";

function Rider() {

    const [showAdd, setShowAdd] = useState(false);
    const [showEdit, setShowEdit] = useState(false);

    const [editId, setEditId] = useState("");

    function ToggleShow() {
        setShowAdd((prevValue) => !prevValue);
    }
    function ToggleEdit() {
        setShowEdit((prevValue) => !prevValue);
    }

    useEffect(() => {
        axios
            .post(`http://192.168.101.9:4000/api/v1/login`, {
                email: 'aaryan@gmail.com',
                password: `password`
            })
            .then(res => console.log(res.data.token))
            .catch(err => console.log(err.message));
    }, [])

    return (
        <div className="main-container">
            <div className="order-content">
                <Top
                    title="Rider Details"
                    ToggleShow={ToggleShow}
                />
                <Table ToggleEdit={ToggleEdit} setId={setEditId} />
            </div>
            <RiderAdd showAdd={showAdd} ToggleShow={ToggleShow} />
            <RiderEdit showEdit={showEdit} ToggleEdit={ToggleEdit} id={editId} />
        </div>
    );
}

export default Rider;