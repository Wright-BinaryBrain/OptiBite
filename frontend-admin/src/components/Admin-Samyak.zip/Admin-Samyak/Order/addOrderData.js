const oData = [
    {
        id: 1,
        item: "./RiderPP/pp.jpg",
        description: "Fresh Organic Cabbage",
        price: 300,
        qty: 3,
        subtotal: 900
    },
    {
        id: 2,
        item: "./RiderPP/pp.jpg",
        description: "Fresh Organic Cabbage",
        price: 300,
        qty: 3,
        subtotal: 900
    },
    {
        id: 3,
        item: "./RiderPP/pp.jpg",
        description: "Fresh Organic Cabbage",
        price: 300,
        qty: 3,
        subtotal: 900
    }
]

export default oData;