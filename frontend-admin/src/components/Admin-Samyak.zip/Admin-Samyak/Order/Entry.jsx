import React, { useEffect } from "react";
import ButtonT from "../ButtonToggle";
import { useState } from "react";

function Entry(props) {
  const [pColor, setPColor] = useState(props.pStatus);
  const [oColor, setOColor] = useState(props.oStatus);
  const [rColor, setRColor] = useState(props.aRider);
  const [riders, setRiders] = useState();
  const changeClassP = (e) => {
    let val = e.target.value;
    setPColor(val);
  };

  const changeClassO = (e) => {
    let val = e.target.value;
    setOColor(val);
  };

  const changeClassR = (e) => {
    let val = e.target.value;
    setRColor(val);
  };
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          `http://localhost:4000/api/v1/getAllRider`
        );
        const json = await response.json();
        setRiders(json.data);
      } catch (error) {
        console.log("error", error);
      }
    };

    fetchData();
  }, []);

  return (
    <tr key={props.id}>
      <td>{props.id}</td>
      <td>{props.uname}</td>
      <td>{props.date}</td>
      <td>
        {props.amount.reduce(
          (accumulator, currentValue) => accumulator + currentValue
        )}
      </td>
      <td>
        <select
          onChange={changeClassP}
          value={pColor}
          className={
            pColor === "Paid"
              ? "Paid"
              : pColor === "Unpaid"
              ? "Unpaid"
              : "Refunded"
          }
          id="paymentS"
        >
          <option value={"Paid"}>Paid</option>
          <option value={"Unpaid"}>Unpaid</option>
          <option value={"Refunded"}>Refunded</option>
        </select>
      </td>
      <td>
        <select
          onChange={changeClassO}
          value={oColor}
          className={
            oColor === "Completed"
              ? "Completed"
              : oColor === "InProgress"
              ? "InProgress"
              : oColor === "BeingDelivered"
              ? "BeingDelivered"
              : oColor === "Pending"
              ? "Pending"
              : "Cancelled"
          }
          id="orderS"
        >
          <option value={"Completed"}>Completed</option>
          <option value={"InProgress"}>In Progress</option>
          <option value={"BeingDelivered"}>Being Delivered</option>
          <option value={"Pending"}>Pending</option>
          <option value={"Cancelled"}>Cancelled</option>
        </select>
      </td>
      <td>
        <select
          onChange={changeClassR}
          value={rColor}
          className={rColor === "" ? "Unassigned" : "Paid"}
          id="riderA"
        >
          <option value="">Assign</option>
          {riders?.map((e) => {
            return <option value={e._id}>{e.riderName}</option>;
          })}
        </select>
      </td>
      <ButtonT
        delOrder={props.delOrder}
        showView={props.showView}
        setId={props.setId}
        id={props.id}
        showEdit={props.showEdit}
      />
    </tr>
  );
}

export default Entry;
