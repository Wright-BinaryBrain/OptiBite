export const COLUMNS = [
    {
        Header: '#ORDER ID',
        accessor: 'id',
    },
    {
        Header: 'Username',
        accessor: 'username',
    },
    {
        Header: 'Date',
        accessor: 'date',
    },
    {
        Header: 'Amount',
        accessor: 'amount',
    },
    {
        Header: 'Payment Status',
        accessor: 'paymentS',
    },
    {
        Header: 'Order Status',
        accessor: 'orderS',
    },
    {
        Header: 'Assign Rider',
        accessor: 'riderA',
    },
]