const nav = [
    {
        id: 1,
        text: "All"
    },
    {
        id: 2,
        text: "Pending"
    },
    {
        id: 3,
        text: "In Progress"
    },
    {
        id: 4,
        text: "Completed"
    },
    {
        id: 5,
        text: "Cancelled"
    },
    {
        id: 5,
        text: "Being Delivered"
    }
]

export default nav;