const data = [
    {
        id: "1",
        username: "msamyak",
        date: "2/1/2022",
        message: "Et dolores quidem enim corporis et illum rem ea aut. Adipisci beatae aut quia ducimus. Sunt veniam ex maxime dolore eum doloribus quae cupiditate. "
    },
    {
        id: "2",
        username: "aryan",
        date: "2/1/2022",
        message: "Et dolores quidem enim corporis et illum rem ea aut. Adipisci beatae aut quia ducimus. Sunt veniam ex maxime dolore eum doloribus quae cupiditate. "
    }
]

export default data;